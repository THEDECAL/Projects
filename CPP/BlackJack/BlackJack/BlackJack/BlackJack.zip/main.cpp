#include <iostream>
#include <time.h>
#include "player.h"

int main(){
	srand(time(NULL));

	//deck first;
	//first.init_deck();
	//first.get();

	//game->start_menu();
	//player second;
	//second.add_card(first[0]);
	//second.add_card(first[1]);
	//second.add_card(first[2]);
	//second.get();
	//first.get();
	
	player _player;
	_player.set_name("Gamer");
	player croupier(true);
	_player.set_name("Croupier");

	croupier.get_deck();
	croupier.add_card(croupier.issue_card());
	croupier.add_card(croupier.issue_card());
	croupier.get();

	_player.add_card(croupier.issue_card());
	_player.add_card(croupier.issue_card());
	_player.get();

	std::system("pause");
	return 0;
}