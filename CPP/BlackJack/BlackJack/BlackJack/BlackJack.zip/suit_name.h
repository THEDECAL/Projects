enum suit{
	suit0=0,
	white,
	black,
	heart,
	diamond,
	club,
	spade
};
enum name{
	name0=0,
	card2=2,
	card3,
	card4,
	card5,
	card6,
	card7,
	card8,
	card9,
	card10,
	jack,
	queen,
	king,
	ace,
	jocker
};
