#include "player.h"
#include <string.h>

player::player(const bool& croupier){
	if(croupier)
		_deck.init_deck();
	cards=NULL;
	cntCards=0;
	strcpy_s(name,"Player");
	score=0;
}
player::player(const player& o){
	strcpy_s(this->name,o.name);
	utility::arrayToArray(this->cards,o.cards,cntCards);
	this->cntCards=o.cntCards;
	this->score=o.score;
}
player& player::operator=(const player& o){
	strcpy_s(this->name,o.name);
	utility::arrayToArray(this->cards,o.cards,cntCards);
	this->cntCards=o.cntCards;
	this->score=o.score;

	return *this;
}
void player::set_name(const char* name){
	strncpy_s(this->name,name,SIZE_NAME-1);
}
card player::issue_card(){
	if(_deck.get_cntCards())
		--_deck;
	return _deck[_deck.get_cntCards()];
}
void player::add_card(const card& refCard){
	score+=refCard.get_value();
	if (cntCards){
		if(cards[0].get_value()==ace&&refCard.get_value()==ace)
			score-=20;
		card *temp = new card[cntCards + 1];
		utility::arrayToArray(temp, cards, cntCards);
		delete[]cards;
		cards = new card[cntCards + 1];
		utility::arrayToArray(cards, temp, cntCards);
		cards[cntCards]=refCard;
		delete[]temp;
	}
	else{
		cards = new card[cntCards + 1];
		cards[cntCards] = refCard;
	}
	cntCards++;
}
void player::get_deck(){
	_deck.get();
}
void player::get(){
	std::cout<<"----------------\n";
	std::cout<<"Name: "<<name<<"\n";
	std::cout<<"----------------\n";
	std::cout<<"Cards: "<<"\n";
	for(int i=0; i<cntCards; i++)
		cards[i].get();
	std::cout<<"\n";
	std::cout<<"----------------\n";
	std::cout<<"Score: "<<score<<"\n";
	std::cout<<"----------------\n";
}
player::~player(){
	if(cards) delete[]cards;
}
