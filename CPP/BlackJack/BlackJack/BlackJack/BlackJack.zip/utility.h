#pragma once

static class utility{
	utility();
	//~utility();
	public:
	template <typename TYPE>
	static void arrayToArray(TYPE* toArray,const TYPE* ofArray,const int& size){
		for(int i=0; i<size; i++)
			toArray[i]=ofArray[i];
	}
};
