#include "card.h"

card::card(const card& o){
	this->_name=o._name;
	this->_suit=o._suit;
}
void card::set(const int &_name,const int &_suit){
	this->_name=(name)_name;
	this->_suit=(suit)_suit;
}
void card::get(){
	std::cout<<(char)_suit;
	switch(_name){
		case jocker: std::cout<<"Jocker"; break;
		case jack: std::cout<<"Jack"; break;
		case queen: std::cout<<"Queen"; break;
		case king: std::cout<<"King"; break;
		case ace: std::cout<<"Ace"; break;
		default: std::cout<<_name; break;
	};
	std::cout<<std::boolalpha;
	std::cout<<(char)_suit<<"\t";
}
int card::get_value()const{
	if(_name==ace) return 11;
	else if(_name>card9) return 10;
	else return _name;
}
card& card::operator=(const card& o){
	this->_name=o._name;
	this->_suit=o._suit;

	return *this;
}